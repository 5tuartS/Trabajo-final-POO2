package Observer.Strategy;

import Observer.Notificacion;

public interface NotificacionStrategy {
    void notificar(Notificacion notificacion);
}

package controlador;

import vista.InicioSesion;

public class MainControlador {

    public static void main(String[] args) {
        new InicioSesionControlador(new InicioSesion());

    }
}
